#!/bin/bash

for i in {1..100}
do
   go test >> output2.txt
done
