#!/bin/bash

for i in {1..25}
do
   go test >> output2.txt
done
